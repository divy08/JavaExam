class Person {
	String Name;
	int Age;
	
	public Person(String Name,int Age)
	{
		this.Name=Name;
		this.Age=Age;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public int getAge() {
		return Age;
	}

	public void setAge(int age) {
		Age = age;
	}
	
	
}

class Patient extends Person{
	
	int Id;
	String Ailment;

	public Patient(String Name, int Age) {
		super(Name, Age);
	}

	public Patient(String Name, int Age, int id, String ailment) {
		super(Name, Age);
		Id = id;
		Ailment = ailment;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getAilment() {
		return Ailment;
	}

	public void setailment(String ailment) {
		Ailment = ailment;
	}
	
	
}

public class Hospital{
	public static void main(String[] args) {
		
		Patient e1 = new Patient("Amit",20);
		System.out.println(e1.getAge());
		System.out.println(e1.getName());
		
		System.out.println("Constructor using all parameters");
		Patient e2 = new Patient("deva",25,112,"Cancer");
		System.out.println(e2.getAge());
		System.out.println(e2.getName());
		System.out.println(e2.getId());
		System.out.println(e2.getAilment());
	}
	
}

