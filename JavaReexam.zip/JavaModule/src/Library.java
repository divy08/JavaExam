import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

class Product {
    private int id;
    private String book;
    private String author;
    private String quantity;

    public Product(int id, String book,String author, String quantity) {
        this.id = id;
        this.book = book;
        this.author = author;
        this.quantity = quantity;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return book;
    }
    
    public String getAuthor() {
        return author;
    }

    public String getQuantity() {
        return quantity;
    }


    @Override
    public String toString() {
        return "Product [ID=" + id + ", Name=" + book + ",Author=" + author + ", Quantity=" + quantity + "]";
    }
}

public class Library {

    private static Scanner scanner = new Scanner(System.in);
    private static ArrayList<Product> prodCata = new ArrayList<>();

    public static void main(String[] args) {
        int choice;
        do {
            showMenu();
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline left-over
            switch (choice) {
                case 1:
                    addBook();
                    break;
                case 2:
                    removeBook();
                    break;
                case 3:
                    displayAllBook();
                    break;
                case 4:
                    findBooksByAuthor();
                    break;
                case 5:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);

        scanner.close();
    }

    private static void showMenu() {
        System.out.println("\nMenu:");
        System.out.println("1. Add a new Book");
        System.out.println("2. Remove a Book");
        System.out.println("3. Display all Books");
        System.out.println("4. Find all Books by Author");
        System.out.println("5. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void addBook() {
        System.out.println("\nEnter Book details:");
        System.out.print("ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Name: ");
        String name = scanner.nextLine();
        System.out.print("Author: ");
        String author = scanner.nextLine();
        System.out.print("Quantity: ");
        String quantity = scanner.nextLine();
        prodCata.add(new Product(id, name, author, quantity));
        System.out.println("Book added successfully.");
    }

    private static void removeBook() {
        System.out.print("\nEnter ID to remove: ");
        int removeId = scanner.nextInt();
        boolean removed = false;
        Iterator<Product> iterator = prodCata.iterator();
        while (iterator.hasNext()) {
            Product product = iterator.next();
            if (product.getId() == removeId) {
                iterator.remove();
                removed = true;
                System.out.println("Book with ID " + removeId + " removed successfully.");
                break;
            }
        }
        if (!removed) {
            System.out.println("Book with ID " + removeId + " not found.");
        }
    }

    private static void displayAllBook() {
        System.out.println("\nAll Books:");
        for (Product product : prodCata) {
            System.out.println(product.toString());
        }
    }

    private static void findBooksByAuthor() {
        System.out.print("\nEnter Author to search: ");
        String searchAuthor = scanner.nextLine();
        boolean found = false;
        for (Product product : prodCata) {
            if (product.getAuthor() == searchAuthor) {
                System.out.println(product.toString());
                found = true;
            }
        }
        if (!found) {
            System.out.println("No Book found with Author Name : " + searchAuthor);
        }
    }
}
