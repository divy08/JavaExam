import java.util.ArrayList;
import java.util.Scanner;

class ItemNotFound extends Exception
{
	public ItemNotFound(String msg) {
		super(msg);
	}
}

class InsufficientStock extends Exception
{
	public InsufficientStock(String msg) {
		super(msg);
	}
}

class InvaidQuantity extends Exception
{
	public InvaidQuantity(String msg) {
		super(msg);
	}
}

class App{
	Scanner sc = new Scanner(System.in);
	String product;
	int quantity;
	boolean expired;
	
	public App(String product, int quantity ) {
		super();
		this.product = product;
		this.quantity = quantity;
		
	}
	
	
	@Override
	public String toString() {
		return "App [Product=" + product + ", Qyantity=" + quantity + "]";
	}


	ArrayList<App> list = new ArrayList<>();
	public App() {
		list.add(new App("Soap", 123));
		list.add(new App("shampoo", 555));
		list.add(new App("Brush", 999));

		
	}
	
	public void DisplayAcc() throws ItemNotFound, InsufficientStock, InvaidQuantity 
	{
		System.out.println("Enter Product: ");
		String prob = sc.nextLine();
		
		for(App a:list) {
			if(a.product.equalsIgnoreCase(prob))
			{
				System.out.println("Product Available");
				System.out.println("Enter Qyantity: ");
				int quant = sc.nextInt();
				if(quant>0) {
					if(a.quantity>=quant)
					{
						System.out.println("Stock Available");
					}
					else {
						
						throw new  InsufficientStock("Insufficient Stock");
					}
				}
				else {
					throw new  InvaidQuantity("Invaid Quantity");
				}
				
			}
			else {
				throw new ItemNotFound ("Item Not Found");
			}
		}
		
	}
	
	
}

public class Warehouse {
	public static void main(String[] args) {
		
	
	App a = new App();
	try {
		a.DisplayAcc();
	}
	catch (ItemNotFound | InsufficientStock | InvaidQuantity e ) {
		System.out.println(e.getMessage());
	}
	
	}
}